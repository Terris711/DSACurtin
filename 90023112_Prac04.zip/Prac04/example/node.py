class Node:
    def __init__(self, key = None, pointer = None):
        self.key = key
        self.next = pointer
    
    


                        

