class DSANode():
    def __init__(self, key = None, pointer = None):
        self.key = key
        self.pointer = pointer # point to the next node
        

