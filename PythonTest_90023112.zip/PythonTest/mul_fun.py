# mul_fun.py : multiply 3 numbers

def mulNum(a, b, c):
    answer =  a*b*c
    return answer

