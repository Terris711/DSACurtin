#  add_fun.py: add 3 numbers

def addNum(a, b, c):
    answer = a + b + c
    return answer
